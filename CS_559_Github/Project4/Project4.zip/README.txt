README File

Assigment #4

This assigment I used what I had from #2 and used the glMatrix Library instead of the 
canvas translations


My Assigment consists of 4 cubic Hermite curves that are connected together to form a race track loop
Then I have my square race car move along the track in the animation. The different segments of the curve can be 
seen when the check mark at the button of the screen is checked.

The animation of the page is done with reqeustAnimationFrame.

I coded the assigmend in notepad++ and tested in chrome version 93.0.4577.82

I also tried microsoft edge version 93.0.961.52
and Firefox version 92.0