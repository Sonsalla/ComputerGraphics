README File

Assigment #5

This assigment I used what I had from #3 and used the glMatrix Library instead of the 
canvas translations


My Assigment consists of part of the dump truck I made in assigments 2 and 3
but in 3D. I decided to focus on the main body of the truck and the dump part
as I am still getting use to 3D modeling. The camera was the camera used in one 
of the demos to circl around the object and the first slider is used to rotate the
dump part of the truck.

I use sliders to move the camera and dump part of the truck

I coded the assigmend in notepad++ and tested in chrome version 93.0.4577.82

I also tried microsoft edge version 93.0.961.52
and Firefox version 92.0