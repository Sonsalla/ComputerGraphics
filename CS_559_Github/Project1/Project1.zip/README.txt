README FILE

My Assignment consists of multiple shapes that can be moved up and down with the corresponding
labeled sliders. The objective of my project was to create something that mades something more
out of the shapes that I created. Therefore I designed the shapes such that when combined together
they fit insided the square outline in the middle of the canvas.

I used demo on transformations from class to get started. The final result consisted of having
each shape have a drawing function that drew the shape and each slider having a listener so if the
value was changed the corresponding transformation would take place.

I coded the assigmend in notepad++ and tested in chrome version 93.0.4577.82

I also tried microsoft edge version 93.0.961.52
and Firefox version 92.0

The page is fitted for chrome the best, the other browsers may have spacing issues.

I have also included an image of the solution to the puzzle in the zip file